<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Premade_Character_08" tilewidth="16" tileheight="16" tilecount="2296" columns="56">
 <image source="../moderninteriors-win/2_Characters/Character_Generator/0_Premade_Characters/16x16/Premade_Character_08.png" width="896" height="656"/>
</tileset>
