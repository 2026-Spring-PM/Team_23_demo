<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="3_Props_and_Buildings_16x16" tilewidth="16" tileheight="16" tilecount="4480" columns="32">
 <image source="../Modern_Farm_v1.2/16x16/3_Props_and_Buildings_16x16.png" width="512" height="2240"/>
</tileset>
