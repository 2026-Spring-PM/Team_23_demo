<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="KakaoTalk_20260529_163459373" tilewidth="16" tileheight="16" tilecount="32" columns="8">
 <image source="../../../../Documents/카카오톡 받은 파일/KakaoTalk_20260529_163459373.png" width="128" height="64"/>
</tileset>
