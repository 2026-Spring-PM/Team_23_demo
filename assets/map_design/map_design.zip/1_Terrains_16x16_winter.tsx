<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="1_Terrains_16x16_winter" tilewidth="16" tileheight="16" tilecount="736" columns="32">
 <image source="../../../../Downloads/1_Terrains_16x16_winter.png" width="512" height="368"/>
</tileset>
