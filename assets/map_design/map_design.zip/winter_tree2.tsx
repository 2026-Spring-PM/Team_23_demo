<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="winter_tree2" tilewidth="16" tileheight="16" tilecount="9700" columns="50">
 <image source="../../../../Downloads/winter_tree2.png" width="800" height="3104"/>
</tileset>
