<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="2_LivingRoom_16x16" tilewidth="16" tileheight="16" tilecount="720" columns="16">
 <image source="../moderninteriors-win/1_Interiors/16x16/Theme_Sorter/2_LivingRoom_16x16.png" width="256" height="720"/>
</tileset>
