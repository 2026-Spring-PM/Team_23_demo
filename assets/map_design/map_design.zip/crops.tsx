<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="crops" tilewidth="16" tileheight="16" tilecount="760" columns="20">
 <image source="../Modern_Farm_v1.2/16x16/4_Crops_16x16.png" width="320" height="608"/>
</tileset>
