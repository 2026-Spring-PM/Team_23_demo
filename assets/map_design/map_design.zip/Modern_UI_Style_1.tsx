<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Modern_UI_Style_1" tilewidth="16" tileheight="16" tilecount="2623" columns="61">
 <image source="../modernuserinterface-win/16x16/Modern_UI_Style_1.png" width="976" height="688"/>
</tileset>
