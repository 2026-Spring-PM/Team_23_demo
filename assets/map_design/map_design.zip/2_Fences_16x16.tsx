<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="2_Fences_16x16" tilewidth="16" tileheight="16" tilecount="544" columns="32">
 <image source="../Modern_Farm_v1.2/16x16/2_Fences_16x16.png" width="512" height="272"/>
</tileset>
