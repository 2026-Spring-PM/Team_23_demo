<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Room_Builder_Floor_Paths_16x16" tilewidth="16" tileheight="16" tilecount="504" columns="42">
 <image source="../moderninteriors-win/1_Interiors/16x16/Room_Builder_subfiles/Room_Builder_Floor_Paths_16x16.png" width="672" height="192"/>
</tileset>
